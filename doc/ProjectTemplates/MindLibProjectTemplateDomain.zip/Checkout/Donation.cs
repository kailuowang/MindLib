namespace MindHarbor.SampleStore.$safeprojectname$.Checkout {
    public class Donation {
        private int id;
        private Payment payment;
        private float total;
        private User user;

        public Donation(User user) {
            this.user = user;
        }

        private Donation() {}

        public int Id {
            get { return id; }
            private set { id = value; }
        }

        public float Total {
            get { return total; }
            set { total = value; }
        }

        public Payment Payment {
            get { return payment; }
            internal set { payment = value; }
        }

        public User User {
            get { return user; }
            set { user = value; }
        }
    }
}