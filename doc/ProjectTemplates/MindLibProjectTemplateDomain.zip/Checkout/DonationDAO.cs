using System;
using System.Collections.Generic;
using System.Text;
using NHibernate.Expression;

namespace MindHarbor.SampleStore.$safeprojectname$.Checkout
{
    public class DonationDAO : MindHarbor.DomainTemplate.NHDomain.GenericDAOBase<Donation>
    {
        private static readonly DonationDAO instance = new DonationDAO();

        public static DonationDAO Instance {
            get { return instance; }
        }

        public IList<Donation> FindByUser(User u) {
            return FindByCriterion(Expression.Eq("User", u));
        }
    }
}