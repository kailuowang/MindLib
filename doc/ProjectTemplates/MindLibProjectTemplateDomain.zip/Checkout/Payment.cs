using System;
using System.Collections.Generic;
using System.Text;

namespace MindHarbor.SampleStore.$safeprojectname$.Checkout
{
    public class Payment  
    {
        private Donation donation;
        private string ccNum;
        private float total;
        private int id;

        public int Id {
            get { return id; }
            set { id = value; }
        }

        public float Total {
            get { return total; }
            set { total = value; }
        }

        public string CCNum {
            get { return ccNum; }
            set { ccNum = value; }
        }
      

        public Donation Donation {
            get { return donation; }
           private set { donation = value; }
        }

        private Payment() {}
        public Payment(Donation donation) {
            this.donation = donation;
            this.total = donation.Total;
            donation.Payment = this;
        }
    }
}
