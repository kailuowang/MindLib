using System;
using System.Collections;
using System.Web;
using MindHarbor.DomainTemplate.NHDomain;

namespace MindHarbor.SampleStore.$safeprojectname$ {
    /// <summary>
    /// Summary description for SampleStoreDomainSession.
    /// </summary>
    public class SampleStoreDomainSession : DomainSessionBase {

 
        public SampleStoreDomainSession() {
         
        }

        private int userId;

        public User User {
            get{ if(userId > 0)
                    return UserDAO.Instance.FindById(userId);        
                else 
                    return null;
            }set {
                if (value != null)
                    userId = value.Id;
                else
                    userId = 0;
            }
        }


        /// <summary>
        /// get the current domainLayer object, that is related to current session
        /// </summary>
        public new static SampleStoreDomainSession Current {
            get {
                return (SampleStoreDomainSession) DomainSessionBase.Current;
            }
        }

    }
}