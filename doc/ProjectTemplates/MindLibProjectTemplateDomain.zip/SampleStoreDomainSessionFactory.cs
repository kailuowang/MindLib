using System;
using MindHarbor.DomainTemplate.NHDomain;
using MindHarbor.SampleStore.$safeprojectname$;

namespace MindHarbor.SampleStore.$safeprojectname$ {
    /// <summary>
    /// Summary description for SampleStoreDomainSessionFactory.
    /// </summary>
    public class SampleStoreDomainSessionFactory : DomainSessionFactoryBase 
    {

        public override DomainSessionBase Create()
        {
            return new SampleStoreDomainSession();
        }

    }
} 
