namespace MindHarbor.SampleStore.$safeprojectname$ {
    public class User {
        private int id;

        private string name;

        private User() {}

        public User(string name) {
            Name = name;
        }

        public int Id {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// The unique name of the plan
        /// </summary>
        public string Name {
            get { return name; }
            set { name = value; }
        }
    }
}