using System;
using System.Collections.Generic;
using System.Text;
using MindHarbor.SampleStore.$safeprojectname$.Checkout;
using NHibernate.Expression;

namespace MindHarbor.SampleStore.$safeprojectname$
{
    public class UserDAO : MindHarbor.DomainTemplate.NHDomain.GenericDAOBase<User>
    {
        private static readonly UserDAO instance = new UserDAO();

        public static UserDAO Instance {
            get { return instance; }
        }

        public override void Delete(User u) {
            foreach (Donation order in DonationDAO.Instance.FindByUser(u)) 
                order.User = null;
            base.Delete(u);
        }
    }
}