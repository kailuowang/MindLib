using MindHarbor.SampleStore.Domain;
using MindHarbor.SampleStore.Domain.Checkout;
using NUnit.Framework;

namespace MindHarbor.SampleStore.$safeprojectname$.Checkout {
    [TestFixture]
    public class CheckoutFixture :  TestBase {
        [Test]
        public void UserCrudTest() {
            User u = dataProvider.User(); 
            CommitAndClearSession();
            Assert.IsNotNull(UserDAO.Instance.FindById(u.Id));
        }
        
        [Test]
        public void DonationCrudTest() {
            User u = dataProvider.User();
            Donation o = dataProvider.Donation(u);
            float t = (float) 343.3;
            o.Total = t;
            CommitAndClearSession();
            o = DonationDAO.Instance.FindById(o.Id);
            Assert.IsNotNull(o);
            Assert.AreEqual(t,o.Total);
        } 
        
        [Test]
        public void PaymentCrudTest() {
            User u = dataProvider.User();
            Donation o = dataProvider.Donation(u);
            float t = (float)343.3;
            o.Total = t;
            Payment p = dataProvider.Payment(o);
            CommitAndClearSession();
            o = DonationDAO.Instance.FindById(o.Id);
            Assert.IsNotNull(o);
            Assert.IsNotNull(o.Payment);
            Assert.AreEqual(t, o.Payment.Total);
        }
        
    }
}