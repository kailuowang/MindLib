using System;
using System.Collections.Generic;
using System.Text;
using MindHarbor.SampleStore.Domain;
using MindHarbor.SampleStore.Domain.Checkout;

namespace MindHarbor.SampleStore.$safeprojectname$
{
    public class MHSSTestDataProvider : MindHarbor.TestUtil.DataProviderBase
    {

        public Donation Donation(User u) {
           Donation o = new Donation(u);
           DonationDAO.Instance.Save(o);
            AddCreatedData(o);
            return o;
        }  

        public User User() {
            User  u = new User(RandomName());
            UserDAO.Instance.Save(u);
            AddCreatedData(u);
            return u;
        }

        public Payment Payment(Donation o) {
            Payment p = new Payment(o);
            return p;
        }
    }
}
