using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace MindHarbor.SampleStore.$safeprojectname$.Special
{
    [TestFixture, Explicit]
    public class CreateDB
    {
        [Test]
        public void Create(){
            MindHarbor.DomainTemplate.NHDomain.Configuration.CreateDatabase();
        }
    }
}
