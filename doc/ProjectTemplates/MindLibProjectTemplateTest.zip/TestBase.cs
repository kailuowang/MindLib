using System;
using System.Collections.Generic;
using System.Text;

namespace MindHarbor.SampleStore.$safeprojectname$
{
    public class TestBase : MindHarbor.TestUtil.TestBase
    {
        protected MHSSTestDataProvider dataProvider {
            get{ return (MHSSTestDataProvider) tdp;}
        }

        protected override MindHarbor.TestUtil.DataProviderBase CreateDataProvider()
        {
            return new MHSSTestDataProvider();
        }
    }
}
