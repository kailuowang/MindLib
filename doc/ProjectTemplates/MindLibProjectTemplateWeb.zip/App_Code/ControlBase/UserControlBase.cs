using System;
using System.Data;
using System.Configuration;
using System.$safeprojectname$;
using System.$safeprojectname$.Security;
using System.$safeprojectname$.UI;
using System.$safeprojectname$.UI.WebControls;
using System.$safeprojectname$.UI.WebControls.WebParts;
using System.$safeprojectname$.UI.HtmlControls;

/// <summary>
/// Summary description for UserControlBase
/// </summary>
public class UserControlBase : UserControl 
{
    public UserControlBase()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    protected virtual IMessageBox MessageBox
    {
        get { return ControlContainer.Current.MessageBox; }
    }

}
