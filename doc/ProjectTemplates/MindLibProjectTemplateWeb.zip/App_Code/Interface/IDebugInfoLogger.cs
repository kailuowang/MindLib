using System;
using System.Data;
using System.Configuration;
using System.$safeprojectname$;
using System.$safeprojectname$.Security;
using System.$safeprojectname$.UI;
using System.$safeprojectname$.UI.WebControls;
using System.$safeprojectname$.UI.WebControls.WebParts;
using System.$safeprojectname$.UI.HtmlControls;

/// <summary>
/// Summary description for IDebugInfoLogger
/// </summary>
public interface IDebugInfoLogger
{
    bool Add(string msg, string key);
    bool Add(string msg);
}

public interface IHasDebugInfoLogger {
    IDebugInfoLogger DebugInfoLogger{ get; set;}
}
