using System;
using System.Data;
using System.Configuration;
using System.$safeprojectname$;
using System.$safeprojectname$.Security;
using System.$safeprojectname$.UI;
using System.$safeprojectname$.UI.WebControls;
using System.$safeprojectname$.UI.WebControls.WebParts;
using System.$safeprojectname$.UI.HtmlControls;

/// <summary>
/// An control/page that can offer a IMessageBox control
/// </summary>
public interface IHasMessageBox
{
     IMessageBox MessageBox { get; }
}
