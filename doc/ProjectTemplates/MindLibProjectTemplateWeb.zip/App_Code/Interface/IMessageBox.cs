using System;
using System.Collections.Generic;
using System.$safeprojectname$.UI;
using MindHarbor.GenClassLib.Validation;

/// <summary>
/// The interface for the control GeneralCotnrol/Msg.ascx
/// </summary>
public interface IMessageBox {
    event EventHandler Confirmed;
    event EventHandler Cancelled;

    string CallerId { get; }


    bool ShowCancelButton { get; set; }

    string OkButtonText { get; set; }

    string CancelButtonText { get; set; }

    string Title { set; }

    string Message { set; }

    void Confirm(string title, string info);
    void Confirm(string title, string info, Control caller);
    void Alert(string title, string info);
    void Alert(string title );
    void ErrorMsg(string title, string info, ICollection<ValidationError> ves);
}