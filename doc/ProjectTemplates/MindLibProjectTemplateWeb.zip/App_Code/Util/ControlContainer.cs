using System.$safeprojectname$;

/// <summary>
/// Summary description for ControlContainer
/// </summary>
public class ControlContainer : IHasMessageBox {
    private IMessageBox messageBox;
    private ControlContainer() {}


    public static ControlContainer Current {
        get {
            if (HttpContext.Current.Items[typeof (ControlContainer)] == null)
                HttpContext.Current.Items[typeof (ControlContainer)] = new ControlContainer();
            return (ControlContainer) HttpContext.Current.Items[typeof (ControlContainer)];
        }
    }

    public IMessageBox MessageBox {
        get { return messageBox;  }
        set{ messageBox = value;}
    }
}