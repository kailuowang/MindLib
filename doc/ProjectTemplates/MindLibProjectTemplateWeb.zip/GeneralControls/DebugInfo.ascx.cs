using System;
using System.Collections.Generic;
using System.Data;
using System.Configuration;
using System.$safeprojectname$;
using System.$safeprojectname$.Security;
using System.$safeprojectname$.UI;
using System.$safeprojectname$.UI.WebControls;
using System.$safeprojectname$.UI.WebControls.WebParts;
using System.$safeprojectname$.UI.HtmlControls;

public partial class GeneralControls_DebugInfo : UserControl, IDebugInfoLogger
{
    private readonly IDictionary<string, string> messages = new Dictionary<string, string>();

    protected override void OnInit(EventArgs e)
    {
        if (Page is IHasDebugInfoLogger)
            ((IHasDebugInfoLogger) Page).DebugInfoLogger = this;
        base.OnInit(e);
    }
    protected void Page_Load(object sender, EventArgs e)
    {}

    /// <summary>
    /// 
    /// </summary>
    /// <param name="message"></param>
    /// <param name="key"></param>
    /// <returns>return true if the old message is replaced</returns>
    public bool Add(string message, string key) {
        if(string.IsNullOrEmpty(key))
            key = message.GetHashCode().ToString();
        bool exists = messages.ContainsKey(key);
        if (exists) 
            messages[key] = message;
        else 
            messages.Add(key, message);

        dlMessages.DataSource = messages.Values;
        dlMessages.DataBind();
        upMain.Update();
        return exists; 
    }

    public bool Add(string message) {
        return Add(message, null);
    }

    protected void ItemDataBound(object sender, DataListItemEventArgs e) {
        Literal lmsg = e.Item.FindControl("lMsg") as Literal;
        if (lmsg != null)
            lmsg.Text = e.Item.DataItem.ToString();
    }
}
