using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.$safeprojectname$;
using System.$safeprojectname$.Security;
using System.$safeprojectname$.UI;
using System.$safeprojectname$.UI.WebControls;
using System.$safeprojectname$.UI.WebControls.WebParts;
using System.$safeprojectname$.UI.HtmlControls;

public partial class GeneralControl_Indicator : System.$safeprojectname$.UI.UserControl {
    protected void Page_Load(object sender, EventArgs e) {

    }
}
