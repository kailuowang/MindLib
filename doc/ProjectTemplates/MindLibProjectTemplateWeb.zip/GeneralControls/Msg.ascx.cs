using System;
using System.Collections.Generic;
using System.$safeprojectname$.UI;
using System.$safeprojectname$.UI.WebControls;
using AjaxControlToolkit;
using MindHarbor.DomainTemplate.WebUtil;
using MindHarbor.GenClassLib.Validation;

public partial  class GeneralControl_Msg :  UserControlBase, IMessageBox {
    public event EventHandler Confirmed;
    public event EventHandler Cancelled;
     
    #region public properties

    [StatefulField] protected string  callerId;

    public string  CallerId {
        get { return callerId; }
        private set { callerId = value; }
    }
   
    public bool ShowCancelButton {
        get {
            if (ViewState["ShowCancelButton"] == null)
                ViewState["ShowCancelButton"] = true;
            return (bool) ViewState["ShowCancelButton"];
        }
        set { ViewState["ShowCancelButton"] = value; }
    }

    public string OkButtonText {
        get {
            if (ViewState["OkButtonText"] == null)
                ViewState["OkButtonText"] = "  Ok  ";
            return (string) ViewState["OkButtonText"];
        }
        set { ViewState["OkButtonText"] = value; }
    }

    public string CancelButtonText {
        get {
            if (ViewState["CancelButtonText"] == null)
                ViewState["CancelButtonText"] = "Cancel";
            return (string) ViewState["CancelButtonText"];
        }
        set { ViewState["CancelButtonText"] = value; }
    }

    protected void Page_Load(object sender, EventArgs e) {}

    public string Title {
        set { ltTitle.Text = value; }
    }

    public string Message {
        set { ltMsgInfo.Text = value; }
    }

    protected override IMessageBox MessageBox
    {
        get
        {
            return this;
        }
    }

    #endregion

    protected void btnCancel_Click(object sender, EventArgs e) {
       
        Hide();
        if (Cancelled != null) Cancelled(this, null);
    }

    protected void btnOk_Click(object sender, EventArgs e) {
        Hide();
        if (Confirmed != null) Confirmed(this, null);
    }

    protected override void OnPreRender(EventArgs e) {
        btnCancel.Visible = ShowCancelButton;
        btnCancel.Text = CancelButtonText;
        phDetailInfo.Visible = !string.IsNullOrEmpty(ltMsgInfo.Text);
        btnOk.Text = OkButtonText;
        base.OnPreRender(e);
    }

    #region Public Methods
    public void Confirm(string title, string info)
    {
        Confirm(title, info, null);
    }

 public void Confirm(string title)
    {
        Confirm(title, string.Empty, null);
    }

    public void Confirm(string title, string info, Control caller)
    {
        CallerId = caller != null ? caller.ID : null;
        Show(title, info, true);
    }

    public void Alert(string title, string info)
    {
        Show(title, info, false);
    } 
    
    public void Alert(string title)
    {
        Show(title, string.Empty, false);
    }

    public void ErrorMsg(string title, string info, ICollection<ValidationError> ves)
    {
        string errMsg = MindHarbor.GenControlLib.MiscUtil.ValidationUtil.BuildErrorMessage(info, ves);
        Alert(title, errMsg);
    } 
    #endregion

    #region Private Methods
    private void Show(string title, string info, bool showCancelButton)
    {
        Title = title;
        Message = info;
        ShowCancelButton = showCancelButton;
        Show();
    }


    private void Show()
    {
        upMain.Update();
        upInner.Update();
        divInner.Visible = true;

        ModalPopupExtender1.Show();
    }

    private void Hide()
    {

        ModalPopupExtender1.Hide();
        upMain.Update();
        divInner.Visible = false;
    } 
    #endregion
}