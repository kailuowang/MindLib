using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.$safeprojectname$;
using System.$safeprojectname$.Security;
using System.$safeprojectname$.UI;
using System.$safeprojectname$.UI.WebControls;
using System.$safeprojectname$.UI.WebControls.WebParts;
using System.$safeprojectname$.UI.HtmlControls;

public partial class PercentageBar : UserControl
{
    public string percentage;
    public string leftPercentage;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    
    public void Bind(int per) {
        if (per < 0 || per > 100)
            throw new ArgumentOutOfRangeException("Percentage must be between 0 and 100");
      
      
        percentage = per.ToString();
        leftPercentage = (100 - per).ToString();
        imgSpacer.ToolTip = percentage;
    }
}
