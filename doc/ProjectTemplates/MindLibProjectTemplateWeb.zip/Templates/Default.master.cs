using System;
using System.$safeprojectname$.UI;


public partial class _DefaultMaster : MasterPage  {
 

    protected override void OnInit(EventArgs e)
    {
   
        if (Request["ajax"] == "0")
            ScriptManager1.EnablePartialRendering = false;
        ControlContainer.Current.MessageBox = Msg1;
        base.OnInit(e);
    }
     
}