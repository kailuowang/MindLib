using System;
using System.$safeprojectname$.UI;
using MindHarbor.DomainTemplate.NHDomain;
using MindHarbor.DomainTemplate.WebUtil;
using MindHarbor.SampleStore.Domain;
using MindHarbor.SampleStore.Domain.Checkout;

public partial class Pages_Checkout : Page {

    [EntityFieldNullSafe] protected Donation placedDonation;
    [ConversationalField] protected Donation placingDonation;
    [StatefulField] protected int step = 0;
    [EntityFieldNullSafe] protected User u;

    protected void Login(object sender, EventArgs e) {
        //find if the user is already registerred if not create a new user accordingly.
            u = new User(tbUserName.Text);
          UserDAO.Instance.Save(u);

        lUserName.Text = u.Name;

        phLogin.Visible = false;
        phEnterTotal.Visible = true;
    }

    protected override void OnPreRender(EventArgs e) {
        step++;
        lVTest.Text = step.ToString();
        base.OnPreRender(e);
    }

    protected void CreateDonation(object sender, EventArgs e) {
        //This line tells our MindHarbor Framework to start a Conversation
        DomainContext.Current.StarLongConversation();
        placingDonation = new Donation(u);
        //Note that the placingDonation is not saved to database at this time.
        placingDonation.Total = Convert.ToSingle(tbTotal.Text);
        phEnterTotal.Visible = false;
        phEnterCCNum.Visible = true;
    }

    protected void EnterCCNum(object sender, EventArgs e) {
        if (!Conversation.Current.IsInPool)
            throw new Exception("Conversation is lost");
        step.ToString();
        if (placingDonation == null)
            throw new Exception("ConverstaionData is lost");
        Payment payment = new Payment(placingDonation);
        payment.CCNum = tbCCNum.Text;
        BindDonationInfo(placingDonation);
        phEnterCCNum.Visible = false;
        phConfirm.Visible = true;
    }

    protected void PlaceDonation(object sender, EventArgs e) {
        //save the conversational data to Database at the last step
        DonationDAO.Instance.Save( placingDonation);

        //save the placing order to placedDonation for testing purpose
        placedDonation = placingDonation;

        //This line tells our MindHarbor Framework to finish the Conversation
        DomainContext.Current.FinishConversation();

        //it is a good practice to reset the conversational data to null when Conversation is done.
        placingDonation = null;
        btnConfirm.Visible = false;
        btnReviewDonation.Visible = true;
    }

    protected void ReviewDonation(object sender, EventArgs e) {
        BindDonationInfo(placedDonation);
    }

    private void BindDonationInfo(Donation donation) {
        lTotal.Text = donation.Total.ToString("C");
        lCCNum.Text = donation.Payment.CCNum;
        lUserName.Text = u.Name;
    }
}