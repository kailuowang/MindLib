using System;
using System.$safeprojectname$.UI;
using MindHarbor.DomainTemplate.WebUtil;
using MindHarbor.SampleStore.Domain;

public partial class TestPages_UserCRUD : Page {
    [EntityField] protected User user;

    public User User {
        get { return user; }
        set {
            user = value;
            BindProperties();
        }
    }

    private void BindProperties() {
        bool isBoundToAUser = User != null;
        if (isBoundToAUser)
            tbName.Text = User.Name;
        phExistingUserOperations.Visible = isBoundToAUser;
    } 

    protected void btnUpdate_Click(object sender, EventArgs e) {
        User.Name = tbName.Text;
        gvUser.DataBind();
    }

    protected void btnDelete_Click(object sender, EventArgs e) {
        UserDAO.Instance.Delete(User);
        User = null;
        gvUser.DataBind(); //Rebind the user list
    }

    protected void gvUser_SelectedIndexChanged(object sender, EventArgs e) {
        User = UserDAO.Instance.FindById((int) gvUser.SelectedDataKey["Id"]);
    }

    protected void btnCreate_Click(object sender, EventArgs e) {
        User = new User(tbName.Text);
        UserDAO.Instance.Save(User);
        gvUser.DataBind();
    }
}